import React, { useState } from 'react';
import { Link } from 'react-router-dom';

// Components for the dashboard
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

const Dashboard = ({ user }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Role-specific content
  const getRoleSpecificContent = () => {
    switch(user.role) {
      case 'homeowner':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <DashboardCard 
              title="Roof Assessment" 
              description="Get an AI-powered assessment of your roof's condition"
              icon="assessment"
              linkTo="/roof-assessment"
            />
            <DashboardCard 
              title="Cost Calculator" 
              description="Calculate the estimated cost of your roofing project"
              icon="calculator"
              linkTo="/cost-calculator"
            />
            <DashboardCard 
              title="Project Tracker" 
              description="Track the progress of your roofing project"
              icon="tracker"
              linkTo="/project-tracker"
            />
          </div>
        );
      case 'contractor':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <DashboardCard 
              title="Active Projects" 
              description="View and manage your active roofing projects"
              icon="projects"
              linkTo="/projects"
            />
            <DashboardCard 
              title="Schedule" 
              description="View your upcoming schedule and appointments"
              icon="schedule"
              linkTo="/schedule"
            />
            <DashboardCard 
              title="Materials" 
              description="Manage materials and inventory for your projects"
              icon="materials"
              linkTo="/materials"
            />
          </div>
        );
      case 'supplier':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <DashboardCard 
              title="Inventory" 
              description="Manage your inventory and stock levels"
              icon="inventory"
              linkTo="/inventory"
            />
            <DashboardCard 
              title="Orders" 
              description="View and manage incoming orders"
              icon="orders"
              linkTo="/orders"
            />
            <DashboardCard 
              title="Deliveries" 
              description="Schedule and track deliveries"
              icon="deliveries"
              linkTo="/deliveries"
            />
          </div>
        );
      case 'insurance':
      case 'adjuster':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <DashboardCard 
              title="Claims" 
              description="View and manage insurance claims"
              icon="claims"
              linkTo="/claims"
            />
            <DashboardCard 
              title="Assessments" 
              description="Review roof damage assessments"
              icon="assessments"
              linkTo="/assessments"
            />
            <DashboardCard 
              title="Reports" 
              description="Generate and view reports"
              icon="reports"
              linkTo="/reports"
            />
          </div>
        );
      default:
        return (
          <div className="text-center py-10">
            <p className="text-gray-500">Welcome to the OrPaynter AI Platform</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} user={user} />
      
      <div className="md:pl-64 flex flex-col flex-1">
        <Header setSidebarOpen={setSidebarOpen} user={user} />
        
        <main className="flex-1">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
              <p className="mt-1 text-sm text-gray-500">
                Welcome back, {user.name}! You are logged in as a {user.role.charAt(0).toUpperCase() + user.role.slice(1)}.
              </p>
            </div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
              {getRoleSpecificContent()}
              
              <div className="mt-10">
                <h2 className="text-lg font-medium text-gray-900">Recent Activity</h2>
                <div className="mt-4 bg-white shadow overflow-hidden sm:rounded-md">
                  <ul className="divide-y divide-gray-200">
                    <ActivityItem 
                      title="Profile setup completed" 
                      description="You completed your profile setup with AI onboarding"
                      date="Today"
                    />
                    <ActivityItem 
                      title="Account created" 
                      description="You created your OrPaynter AI Platform account"
                      date="Today"
                    />
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

// Dashboard Card Component
const DashboardCard = ({ title, description, icon, linkTo }) => {
  const getIcon = (iconName) => {
    switch(iconName) {
      case 'assessment':
        return (
          <svg className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        );
      case 'calculator':
        return (
          <svg className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
        );
      case 'tracker':
        return (
          <svg className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        );
      default:
        return (
          <svg className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
        );
    }
  };

  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            {getIcon(icon)}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dt className="text-lg font-medium text-gray-900 truncate">
              {title}
            </dt>
            <dd className="flex items-baseline text-sm text-gray-500">
              {description}
            </dd>
          </div>
        </div>
      </div>
      <div className="bg-gray-50 px-5 py-3">
        <div className="text-sm">
          <Link to={linkTo} className="font-medium text-blue-600 hover:text-blue-500">
            Access <span aria-hidden="true">&rarr;</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

// Activity Item Component
const ActivityItem = ({ title, description, date }) => {
  return (
    <li>
      <div className="px-4 py-4 sm:px-6">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-blue-600 truncate">
            {title}
          </p>
          <div className="ml-2 flex-shrink-0 flex">
            <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
              {date}
            </p>
          </div>
        </div>
        <div className="mt-2 sm:flex sm:justify-between">
          <div className="sm:flex">
            <p className="flex items-center text-sm text-gray-500">
              {description}
            </p>
          </div>
        </div>
      </div>
    </li>
  );
};

export default Dashboard;
