import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe('pk_test_your_public_key');

const Subscription = ({ user }) => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [subscription, setSubscription] = useState(null);
  const [lifetimeCount, setLifetimeCount] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch subscription plans
    const fetchPlans = async () => {
      try {
        // In a real implementation, this would fetch from your backend
        const plansData = [
          {
            id: 'basic',
            name: 'Basic',
            description: 'Access to basic features',
            price: 9.99,
            features: [
              'AI Roof Damage Assessment',
              'Basic Project Tracking',
              'Email Support'
            ]
          },
          {
            id: 'pro',
            name: 'Professional',
            description: 'Enhanced features for serious users',
            price: 19.99,
            features: [
              'All Basic features',
              'Advanced Cost Calculator',
              'Priority Support',
              'Unlimited Projects'
            ]
          },
          {
            id: 'lifetime',
            name: 'Lifetime Access',
            description: 'One-time payment for lifetime access',
            price: 199.99,
            features: [
              'All Professional features',
              'Lifetime Updates',
              'Premium Support',
              'Early Access to New Features'
            ],
            isLifetime: true,
            limitedSpots: 150
          }
        ];
        
        setPlans(plansData);
        
        // Simulate fetching lifetime count
        setLifetimeCount(Math.floor(Math.random() * 120) + 10); // Random number between 10 and 129
        
        // Simulate fetching user subscription
        const mockSubscription = {
          active: false,
          plan: null,
          expiresAt: null
        };
        
        setSubscription(mockSubscription);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching subscription data:', error);
        setLoading(false);
      }
    };
    
    fetchPlans();
  }, []);

  const handleSubscribe = async (planId) => {
    try {
      // In a real implementation, this would call your backend to create a checkout session
      console.log(`Creating checkout session for plan: ${planId}`);
      
      // Simulate API call to create checkout session
      const sessionId = 'mock_session_id';
      
      // Redirect to checkout
      const stripe = await stripePromise;
      
      // In a real implementation, this would redirect to Stripe checkout
      // For this example, we'll simulate a successful payment
      setTimeout(() => {
        // Update subscription state
        setSubscription({
          active: true,
          plan: planId,
          expiresAt: planId === 'lifetime' ? null : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        });
        
        // If lifetime plan, increment count
        if (planId === 'lifetime') {
          setLifetimeCount(prevCount => prevCount + 1);
        }
        
        // Show success message
        alert('Payment successful! Your subscription is now active.');
      }, 1000);
    } catch (error) {
      console.error('Error creating checkout session:', error);
      alert('There was an error processing your payment. Please try again.');
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Never';
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="mt-6 flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
            <h2 className="mt-4 text-lg font-medium text-gray-900">Loading subscription information...</h2>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="py-10">
        <header>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold leading-tight text-gray-900">Subscription Plans</h1>
          </div>
        </header>
        <main>
          <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div className="px-4 py-8 sm:px-0">
              {subscription && subscription.active ? (
                <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
                  <div className="px-4 py-5 sm:px-6">
                    <h2 className="text-lg leading-6 font-medium text-gray-900">Your Subscription</h2>
                    <p className="mt-1 max-w-2xl text-sm text-gray-500">Details about your current subscription.</p>
                  </div>
                  <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
                    <dl className="sm:divide-y sm:divide-gray-200">
                      <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">Plan</dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          {plans.find(p => p.id === subscription.plan)?.name || subscription.plan}
                        </dd>
                      </div>
                      <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">Status</dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Active
                          </span>
                        </dd>
                      </div>
                      <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">Expires</dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          {subscription.plan === 'lifetime' ? 'Never (Lifetime Access)' : formatDate(subscription.expiresAt)}
                        </dd>
                      </div>
                    </dl>
                  </div>
                </div>
              ) : null}
              
              <div className="space-y-12">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {plans.map((plan) => (
                    <div key={plan.id} className="bg-white overflow-hidden shadow rounded-lg divide-y divide-gray-200">
                      <div className="px-6 py-8">
                        <h3 className="text-lg leading-6 font-medium text-gray-900">{plan.name}</h3>
                        <p className="mt-1 text-sm text-gray-500">{plan.description}</p>
                        <p className="mt-4">
                          <span className="text-4xl font-extrabold text-gray-900">${plan.price}</span>
                          {!plan.isLifetime && <span className="text-base font-medium text-gray-500">/mo</span>}
                        </p>
                        {plan.isLifetime && (
                          <p className="mt-2 text-sm text-gray-500">
                            <span className="font-medium text-blue-600">{150 - lifetimeCount}</span> spots remaining
                          </p>
                        )}
                      </div>
                      <div className="px-6 py-6">
                        <h4 className="text-sm font-medium text-gray-900">What's included</h4>
                        <ul className="mt-4 space-y-3">
                          {plan.features.map((feature, index) => (
                            <li key={index} className="flex">
                              <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                              </svg>
                              <span className="ml-2 text-sm text-gray-500">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="px-6 py-4 bg-gray-50">
                        <button
                          type="button"
                          onClick={() => handleSubscribe(plan.id)}
                          disabled={subscription?.active && subscription?.plan === plan.id}
                          className={`w-full inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                            subscription?.active && subscription?.plan === plan.id
                              ? 'bg-gray-400 cursor-not-allowed'
                              : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
                          }`}
                        >
                          {subscription?.active && subscription?.plan === plan.id
                            ? 'Current Plan'
                            : plan.isLifetime
                            ? 'Buy Lifetime Access'
                            : 'Subscribe'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Subscription;
