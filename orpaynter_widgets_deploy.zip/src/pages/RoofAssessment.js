import React, { useState } from 'react';

const RoofAssessment = ({ user }) => {
  const [step, setStep] = useState(1);
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [assessment, setAssessment] = useState(null);

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const newImages = files.map(file => ({
      file,
      preview: URL.createObjectURL(file)
    }));
    setImages([...images, ...newImages]);
  };

  const removeImage = (index) => {
    const newImages = [...images];
    URL.revokeObjectURL(newImages[index].preview);
    newImages.splice(index, 1);
    setImages(newImages);
  };

  const handleSubmit = async () => {
    setLoading(true);
    
    // Simulate AI analysis with a timeout
    setTimeout(() => {
      // Mock assessment result
      setAssessment({
        damageLevel: 'Moderate',
        damageAreas: [
          { area: 'North-facing slope', damage: 'Shingle displacement', severity: 'Moderate' },
          { area: 'Ridge line', damage: 'Wear and tear', severity: 'Minor' },
          { area: 'South-west corner', damage: 'Water damage', severity: 'Significant' }
        ],
        estimatedCost: {
          min: 3200,
          max: 4800
        },
        recommendedActions: [
          'Replace damaged shingles on north-facing slope',
          'Repair water damage in south-west corner',
          'Inspect and reinforce ridge line'
        ],
        urgency: 'Medium - should be addressed within 3-6 months'
      });
      
      setLoading(false);
      setStep(3);
    }, 3000);
  };

  const renderStepOne = () => (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
      <h2 className="text-xl font-medium text-gray-900 mb-4">Upload Roof Images</h2>
      <p className="text-gray-500 mb-6">
        Upload clear photos of your roof from different angles. Our AI will analyze them to assess damage and provide recommendations.
      </p>
      
      <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
        <div className="space-y-1 text-center">
          <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <div className="flex text-sm text-gray-600">
            <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
              <span>Upload files</span>
              <input id="file-upload" name="file-upload" type="file" className="sr-only" multiple accept="image/*" onChange={handleImageUpload} />
            </label>
            <p className="pl-1">or drag and drop</p>
          </div>
          <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
        </div>
      </div>
      
      {images.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-medium text-gray-900">Uploaded Images</h3>
          <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
            {images.map((image, index) => (
              <div key={index} className="relative">
                <img src={image.preview} alt={`Roof ${index + 1}`} className="h-24 w-full object-cover rounded-md" />
                <button
                  type="button"
                  onClick={() => removeImage(index)}
                  className="absolute top-0 right-0 -mt-2 -mr-2 bg-red-500 text-white rounded-full p-1"
                >
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="mt-6 flex justify-end">
        <button
          type="button"
          onClick={() => setStep(2)}
          disabled={images.length === 0}
          className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${images.length === 0 ? 'bg-gray-300 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'}`}
        >
          Next
        </button>
      </div>
    </div>
  );

  const renderStepTwo = () => (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
      <h2 className="text-xl font-medium text-gray-900 mb-4">Additional Information</h2>
      <p className="text-gray-500 mb-6">
        Please provide some additional details about your roof to help our AI make a more accurate assessment.
      </p>
      
      <div className="space-y-6">
        <div>
          <label htmlFor="roof-age" className="block text-sm font-medium text-gray-700">
            Approximate Roof Age (years)
          </label>
          <select
            id="roof-age"
            name="roof-age"
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
          >
            <option>Less than 5 years</option>
            <option>5-10 years</option>
            <option>10-15 years</option>
            <option>15-20 years</option>
            <option>More than 20 years</option>
            <option>Unknown</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="roof-type" className="block text-sm font-medium text-gray-700">
            Roof Material
          </label>
          <select
            id="roof-type"
            name="roof-type"
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
          >
            <option>Asphalt Shingles</option>
            <option>Metal</option>
            <option>Tile</option>
            <option>Slate</option>
            <option>Wood Shake</option>
            <option>Other</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="recent-issues" className="block text-sm font-medium text-gray-700">
            Recent Issues (select all that apply)
          </label>
          <div className="mt-2 space-y-2">
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="leaks"
                  name="leaks"
                  type="checkbox"
                  className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="leaks" className="font-medium text-gray-700">Leaks</label>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="missing-shingles"
                  name="missing-shingles"
                  type="checkbox"
                  className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="missing-shingles" className="font-medium text-gray-700">Missing Shingles</label>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="water-damage"
                  name="water-damage"
                  type="checkbox"
                  className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="water-damage" className="font-medium text-gray-700">Water Damage</label>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="storm-damage"
                  name="storm-damage"
                  type="checkbox"
                  className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="storm-damage" className="font-medium text-gray-700">Storm Damage</label>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-6 flex justify-between">
        <button
          type="button"
          onClick={() => setStep(1)}
          className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Back
        </button>
        <button
          type="button"
          onClick={handleSubmit}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Submit for Analysis
        </button>
      </div>
    </div>
  );

  const renderStepThree = () => (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h2 className="text-xl font-medium text-gray-900">AI Roof Assessment Results</h2>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">
          Based on the images and information provided, our AI has generated the following assessment.
        </p>
      </div>
      
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-gray-500">Overall Damage Level</dt>
            <dd className="mt-1 text-sm text-gray-900 font-semibold">{assessment.damageLevel}</dd>
          </div>
          
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-gray-500">Urgency</dt>
            <dd className="mt-1 text-sm text-gray-900">{assessment.urgency}</dd>
          </div>
          
          <div className="sm:col-span-2">
            <dt className="text-sm font-medium text-gray-500">Estimated Cost Range</dt>
            <dd className="mt-1 text-sm text-gray-900">${assessment.estimatedCost.min.toLocaleString()} - ${assessment.estimatedCost.max.toLocaleString()}</dd>
          </div>
          
          <div className="sm:col-span-2">
            <dt className="text-sm font-medium text-gray-500">Damage Areas</dt>
            <dd className="mt-1 text-sm text-gray-900">
              <ul className="border border-gray-200 rounded-md divide-y divide-gray-200">
                {assessment.damageAreas.map((area, index) => (
                  <li key={index} className="pl-3 pr-4 py-3 flex items-center justify-between text-sm">
                    <div className="w-0 flex-1 flex items-center">
                      <span className="ml-2 flex-1 w-0 truncate">
                        <span className="font-medium">{area.area}:</span> {area.damage} - <span className={`${area.severity === 'Significant' ? 'text-red-600' : area.severity === 'Moderate' ? 'text-yellow-600' : 'text-green-600'}`}>{area.severity}</span>
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            </dd>
          </div>
          
          <div className="sm:col-span-2">
            <dt className="text-sm font-medium text-gray-500">Recommended Actions</dt>
            <dd className="mt-1 text-sm text-gray-900">
              <ul className="list-disc pl-5 space-y-1">
                {assessment.recommendedActions.map((action, index) => (
                  <li key={index}>{action}</li>
                ))}
              </ul>
            </dd>
          </div>
        </dl>
      </div>
      
      <div className="px-4 py-5 sm:px-6 bg-gray-50 flex justify-between">
        <button
          type="button"
          onClick={() => {
            setStep(1);
            setImages([]);
            setAssessment(null);
          }}
          className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Start New Assessment
        </button>
        <button
          type="button"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Submit Insurance Claim
        </button>
      </div>
    </div>
  );

  const renderLoading = () => (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
      <div className="text-center">
        <svg className="mx-auto h-12 w-12 text-blue-600 animate-spin" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <h3 className="mt-4 text-lg font-medium text-gray-900">Analyzing your roof...</h3>
        <p className="mt-2 text-sm text-gray-500">
          Our AI is processing your images and information to generate a comprehensive assessment.
          This may take a few moments.
        </p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="py-10">
        <header>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold leading-tight text-gray-900">AI Roof Damage Assessment</h1>
          </div>
        </header>
        <main>
          <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div className="px-4 py-8 sm:px-0">
              {/* Progress Steps */}
              <div className="mb-8">
                <div className="flex items-center justify-center">
                  <div className="flex items-center relative">
                    {[1, 2, 3].map((stepNumber) => (
                      <React.Fragment key={stepNumber}>
                        {stepNumber > 1 && (
                          <div className={`flex-1 h-0.5 w-10 ${step >= stepNumber ? 'bg-blue-600' : 'bg-gray-300'}`}></div>
                        )}
                        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${step >= stepNumber ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-500'}`}>
                          {stepNumber}
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                </div>
                <div className="flex justify-between mt-2">
                  <div className="text-center text-sm text-gray-500">Upload Images</div>
                  <div className="text-center text-sm text-gray-500">Additional Info</div>
                  <div className="text-center text-sm text-gray-500">Assessment Results</div>
                </div>
              </div>
              
              {/* Step Content */}
              {loading ? renderLoading() : (
                <>
                  {step === 1 && renderStepOne()}
                  {step === 2 && renderStepTwo()}
                  {step === 3 && renderStepThree()}
                </>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default RoofAssessment;
