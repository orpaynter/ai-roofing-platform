import React, { useState } from 'react';

const CostCalculator = ({ user }) => {
  const [roofSize, setRoofSize] = useState('');
  const [roofType, setRoofType] = useState('asphalt');
  const [roofPitch, setRoofPitch] = useState('medium');
  const [roofComplexity, setRoofComplexity] = useState('simple');
  const [location, setLocation] = useState('');
  const [additionalFeatures, setAdditionalFeatures] = useState({
    removal: false,
    underlayment: false,
    ventilation: false,
    gutters: false,
    skylight: false
  });
  
  const [calculationResult, setCalculationResult] = useState(null);
  
  const roofTypePrices = {
    asphalt: { min: 3.50, max: 5.50, name: 'Asphalt Shingles' },
    metal: { min: 7.00, max: 12.00, name: 'Metal Roofing' },
    tile: { min: 10.00, max: 18.00, name: 'Tile Roofing' },
    slate: { min: 15.00, max: 25.00, name: 'Slate Roofing' },
    wood: { min: 6.00, max: 9.00, name: 'Wood Shake' },
    flat: { min: 5.00, max: 8.00, name: 'Flat/Low Slope' }
  };
  
  const pitchMultipliers = {
    low: { value: 1.0, name: 'Low (1/12 to 3/12)' },
    medium: { value: 1.2, name: 'Medium (4/12 to 8/12)' },
    steep: { value: 1.5, name: 'Steep (9/12 or greater)' }
  };
  
  const complexityMultipliers = {
    simple: { value: 1.0, name: 'Simple (Rectangle, Few Obstacles)' },
    moderate: { value: 1.2, name: 'Moderate (Multiple Levels, Some Obstacles)' },
    complex: { value: 1.5, name: 'Complex (Many Angles, Many Obstacles)' }
  };
  
  const additionalFeaturePrices = {
    removal: { min: 1.00, max: 2.00, name: 'Old Roof Removal' },
    underlayment: { min: 0.50, max: 1.00, name: 'Premium Underlayment' },
    ventilation: { min: 1.00, max: 2.00, name: 'Improved Ventilation' },
    gutters: { min: 1.00, max: 2.50, name: 'New Gutters & Downspouts' },
    skylight: { min: 1000, max: 2500, name: 'Skylight Installation (per unit)' }
  };
  
  const handleAdditionalFeatureChange = (feature) => {
    setAdditionalFeatures({
      ...additionalFeatures,
      [feature]: !additionalFeatures[feature]
    });
  };
  
  const calculateCost = () => {
    if (!roofSize || isNaN(parseFloat(roofSize))) {
      alert('Please enter a valid roof size');
      return;
    }
    
    const size = parseFloat(roofSize);
    const roofTypePrice = roofTypePrices[roofType];
    const pitchMultiplier = pitchMultipliers[roofPitch].value;
    const complexityMultiplier = complexityMultipliers[roofComplexity].value;
    
    // Base cost calculation
    const baseMinCost = size * roofTypePrice.min * pitchMultiplier * complexityMultiplier;
    const baseMaxCost = size * roofTypePrice.max * pitchMultiplier * complexityMultiplier;
    
    // Additional features cost
    let additionalMinCost = 0;
    let additionalMaxCost = 0;
    let additionalFeaturesList = [];
    
    Object.keys(additionalFeatures).forEach(feature => {
      if (additionalFeatures[feature]) {
        const featurePrice = additionalFeaturePrices[feature];
        if (feature === 'skylight') {
          // Skylight is a fixed cost per unit, not per square foot
          additionalMinCost += featurePrice.min;
          additionalMaxCost += featurePrice.max;
        } else {
          additionalMinCost += size * featurePrice.min;
          additionalMaxCost += size * featurePrice.max;
        }
        additionalFeaturesList.push(featurePrice.name);
      }
    });
    
    const totalMinCost = baseMinCost + additionalMinCost;
    const totalMaxCost = baseMaxCost + additionalMaxCost;
    
    setCalculationResult({
      roofSize: size,
      roofType: roofTypePrice.name,
      roofPitch: pitchMultipliers[roofPitch].name,
      roofComplexity: complexityMultipliers[roofComplexity].name,
      location: location,
      additionalFeatures: additionalFeaturesList,
      baseMinCost,
      baseMaxCost,
      additionalMinCost,
      additionalMaxCost,
      totalMinCost,
      totalMaxCost
    });
  };
  
  const resetCalculator = () => {
    setRoofSize('');
    setRoofType('asphalt');
    setRoofPitch('medium');
    setRoofComplexity('simple');
    setLocation('');
    setAdditionalFeatures({
      removal: false,
      underlayment: false,
      ventilation: false,
      gutters: false,
      skylight: false
    });
    setCalculationResult(null);
  };
  
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="py-10">
        <header>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold leading-tight text-gray-900">Roofing Cost Calculator</h1>
          </div>
        </header>
        <main>
          <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div className="px-4 py-8 sm:px-0">
              {!calculationResult ? (
                <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
                  <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                    <div className="sm:col-span-3">
                      <label htmlFor="roof-size" className="block text-sm font-medium text-gray-700">
                        Roof Size (Square Feet)
                      </label>
                      <div className="mt-1">
                        <input
                          type="number"
                          name="roof-size"
                          id="roof-size"
                          value={roofSize}
                          onChange={(e) => setRoofSize(e.target.value)}
                          className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="e.g. 1500"
                        />
                      </div>
                    </div>
                    
                    <div className="sm:col-span-3">
                      <label htmlFor="location" className="block text-sm font-medium text-gray-700">
                        Location (City, State)
                      </label>
                      <div className="mt-1">
                        <input
                          type="text"
                          name="location"
                          id="location"
                          value={location}
                          onChange={(e) => setLocation(e.target.value)}
                          className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="e.g. Austin, TX"
                        />
                      </div>
                    </div>
                    
                    <div className="sm:col-span-3">
                      <label htmlFor="roof-type" className="block text-sm font-medium text-gray-700">
                        Roof Material
                      </label>
                      <div className="mt-1">
                        <select
                          id="roof-type"
                          name="roof-type"
                          value={roofType}
                          onChange={(e) => setRoofType(e.target.value)}
                          className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        >
                          <option value="asphalt">Asphalt Shingles</option>
                          <option value="metal">Metal Roofing</option>
                          <option value="tile">Tile Roofing</option>
                          <option value="slate">Slate Roofing</option>
                          <option value="wood">Wood Shake</option>
                          <option value="flat">Flat/Low Slope</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="sm:col-span-3">
                      <label htmlFor="roof-pitch" className="block text-sm font-medium text-gray-700">
                        Roof Pitch
                      </label>
                      <div className="mt-1">
                        <select
                          id="roof-pitch"
                          name="roof-pitch"
                          value={roofPitch}
                          onChange={(e) => setRoofPitch(e.target.value)}
                          className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        >
                          <option value="low">Low (1/12 to 3/12)</option>
                          <option value="medium">Medium (4/12 to 8/12)</option>
                          <option value="steep">Steep (9/12 or greater)</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="sm:col-span-6">
                      <label htmlFor="roof-complexity" className="block text-sm font-medium text-gray-700">
                        Roof Complexity
                      </label>
                      <div className="mt-1">
                        <select
                          id="roof-complexity"
                          name="roof-complexity"
                          value={roofComplexity}
                          onChange={(e) => setRoofComplexity(e.target.value)}
                          className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        >
                          <option value="simple">Simple (Rectangle, Few Obstacles)</option>
                          <option value="moderate">Moderate (Multiple Levels, Some Obstacles)</option>
                          <option value="complex">Complex (Many Angles, Many Obstacles)</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="sm:col-span-6">
                      <fieldset>
                        <legend className="text-sm font-medium text-gray-700">Additional Features</legend>
                        <div className="mt-4 space-y-4">
                          {Object.keys(additionalFeatures).map((feature) => (
                            <div key={feature} className="flex items-start">
                              <div className="flex items-center h-5">
                                <input
                                  id={feature}
                                  name={feature}
                                  type="checkbox"
                                  checked={additionalFeatures[feature]}
                                  onChange={() => handleAdditionalFeatureChange(feature)}
                                  className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                                />
                              </div>
                              <div className="ml-3 text-sm">
                                <label htmlFor={feature} className="font-medium text-gray-700">
                                  {additionalFeaturePrices[feature].name}
                                </label>
                              </div>
                            </div>
                          ))}
                        </div>
                      </fieldset>
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-end">
                    <button
                      type="button"
                      onClick={calculateCost}
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Calculate Cost
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                  <div className="px-4 py-5 sm:px-6">
                    <h2 className="text-xl font-medium text-gray-900">Roofing Cost Estimate</h2>
                    <p className="mt-1 max-w-2xl text-sm text-gray-500">
                      Based on the information provided, here's your estimated roofing cost.
                    </p>
                  </div>
                  
                  <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
                    <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                      <div className="sm:col-span-1">
                        <dt className="text-sm font-medium text-gray-500">Roof Size</dt>
                        <dd className="mt-1 text-sm text-gray-900">{calculationResult.roofSize.toLocaleString()} sq ft</dd>
                      </div>
                      
                      <div className="sm:col-span-1">
                        <dt className="text-sm font-medium text-gray-500">Location</dt>
                        <dd className="mt-1 text-sm text-gray-900">{calculationResult.location || 'Not specified'}</dd>
                      </div>
                      
                      <div className="sm:col-span-1">
                        <dt className="text-sm font-medium text-gray-500">Roof Material</dt>
                        <dd className="mt-1 text-sm text-gray-900">{calculationResult.roofType}</dd>
                      </div>
                      
                      <div className="sm:col-span-1">
                        <dt className="text-sm font-medium text-gray-500">Roof Pitch</dt>
                        <dd className="mt-1 text-sm text-gray-900">{calculationResult.roofPitch}</dd>
                      </div>
                      
                      <div className="sm:col-span-2">
                        <dt className="text-sm font-medium text-gray-500">Roof Complexity</dt>
                        <dd className="mt-1 text-sm text-gray-900">{calculationResult.roofComplexity}</dd>
                      </div>
                      
                      {calculationResult.additionalFeatures.length > 0 && (
                        <div className="sm:col-span-2">
                          <dt className="text-sm font-medium text-gray-500">Additional Features</dt>
                          <dd className="mt-1 text-sm text-gray-900">
                            <ul className="list-disc pl-5 space-y-1">
                              {calculationResult.additionalFeatures.map((feature, index) => (
                                <li key={index}>{feature}</li>
                              ))}
                            </ul>
                          </dd>
                        </div>
                      )}
                      
                      <div className="sm:col-span-2 border-t border-gray-200 pt-4">
                        <dt className="text-sm font-medium text-gray-500">Base Roofing Cost</dt>
                        <dd className="mt-1 text-sm text-gray-900">
                          ${Math.round(calculationResult.baseMinCost).toLocaleString()} - ${Math.round(calculationResult.baseMaxCost).toLocaleString()}
                        </dd>
                      </div>
                      
                      {(calculationResult.additionalMinCost > 0 || calculationResult.additionalMaxCost > 0) && (
                        <div className="sm:col-span-2">
                          <dt className="text-sm font-medium text-gray-500">Additional Features Cost</dt>
                          <dd className="mt-1 text-sm text-gray-900">
                            ${Math.round(calculationResult.additionalMinCost).toLocaleString()} - ${Math.round(calculationResult.additionalMaxCost).toLocaleString()}
                          </dd>
                        </div>
                      )}
                      
                      <div className="sm:col-span-2 border-t border-gray-200 pt-4">
                        <dt className="text-lg font-medium text-gray-900">Total Estimated Cost</dt>
                        <dd className="mt-1 text-xl font-bold text-blue-600">
                          ${Math.round(calculationResult.totalMinCost).toLocaleString()} - ${Math.round(calculationResult.totalMaxCost).toLocaleString()}
                        </dd>
                      </div>
                    </dl>
                  </div>
                  
                  <div className="px-4 py-5 sm:px-6 bg-gray-50 flex justify-between">
                    <button
                      type="button"
                      onClick={resetCalculator}
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      New Calculation
                    </button>
                    <button
                      type="button"
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Request Detailed Quote
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default CostCalculator;
