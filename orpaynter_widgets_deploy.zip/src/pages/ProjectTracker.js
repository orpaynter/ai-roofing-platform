import React, { useState } from 'react';

const ProjectTracker = ({ user }) => {
  const [projects, setProjects] = useState([
    {
      id: 1,
      name: 'Roof Replacement - Main House',
      address: '123 Main Street, Austin, TX',
      startDate: '2025-04-15',
      estimatedEndDate: '2025-04-25',
      status: 'scheduled',
      contractor: 'ABC Roofing',
      budget: 12500,
      progress: 0,
      tasks: [
        { id: 1, name: 'Initial Assessment', status: 'completed', date: '2025-04-01' },
        { id: 2, name: 'Material Delivery', status: 'pending', date: '2025-04-14' },
        { id: 3, name: 'Roof Removal', status: 'pending', date: '2025-04-15' },
        { id: 4, name: 'New Roof Installation', status: 'pending', date: '2025-04-16' },
        { id: 5, name: 'Cleanup and Final Inspection', status: 'pending', date: '2025-04-25' }
      ],
      updates: [
        { id: 1, date: '2025-04-01', message: 'Project created and scheduled', author: 'System' }
      ]
    }
  ]);
  
  const [selectedProject, setSelectedProject] = useState(projects[0]);
  const [activeTab, setActiveTab] = useState('overview');
  const [newUpdate, setNewUpdate] = useState('');
  
  const getStatusColor = (status) => {
    switch(status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800';
      case 'scheduled':
        return 'bg-yellow-100 text-yellow-800';
      case 'delayed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getStatusText = (status) => {
    switch(status) {
      case 'completed':
        return 'Completed';
      case 'in_progress':
        return 'In Progress';
      case 'scheduled':
        return 'Scheduled';
      case 'delayed':
        return 'Delayed';
      case 'pending':
        return 'Pending';
      default:
        return status.charAt(0).toUpperCase() + status.slice(1);
    }
  };
  
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  const calculateDaysRemaining = (endDate) => {
    const today = new Date();
    const end = new Date(endDate);
    const diffTime = end - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };
  
  const calculateProgress = (tasks) => {
    if (tasks.length === 0) return 0;
    const completedTasks = tasks.filter(task => task.status === 'completed').length;
    return Math.round((completedTasks / tasks.length) * 100);
  };
  
  const handleTaskStatusChange = (taskId, newStatus) => {
    const updatedProjects = projects.map(project => {
      if (project.id === selectedProject.id) {
        const updatedTasks = project.tasks.map(task => {
          if (task.id === taskId) {
            return { ...task, status: newStatus };
          }
          return task;
        });
        
        const progress = calculateProgress(updatedTasks);
        let status = project.status;
        
        // Update project status based on task progress
        if (progress === 100) {
          status = 'completed';
        } else if (progress > 0) {
          status = 'in_progress';
        }
        
        return { 
          ...project, 
          tasks: updatedTasks,
          progress,
          status
        };
      }
      return project;
    });
    
    setProjects(updatedProjects);
    setSelectedProject(updatedProjects.find(p => p.id === selectedProject.id));
  };
  
  const addUpdate = () => {
    if (!newUpdate.trim()) return;
    
    const updatedProjects = projects.map(project => {
      if (project.id === selectedProject.id) {
        const updatedUpdates = [
          ...project.updates,
          {
            id: project.updates.length + 1,
            date: new Date().toISOString().split('T')[0],
            message: newUpdate,
            author: user.name
          }
        ];
        
        return { ...project, updates: updatedUpdates };
      }
      return project;
    });
    
    setProjects(updatedProjects);
    setSelectedProject(updatedProjects.find(p => p.id === selectedProject.id));
    setNewUpdate('');
  };
  
  const renderOverviewTab = () => (
    <div className="space-y-6">
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">Project Details</h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">Key information about your roofing project.</p>
          </div>
          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(selectedProject.status)}`}>
            {getStatusText(selectedProject.status)}
          </span>
        </div>
        <div className="border-t border-gray-200">
          <dl>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Project name</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{selectedProject.name}</dd>
            </div>
            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Address</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{selectedProject.address}</dd>
            </div>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Contractor</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{selectedProject.contractor}</dd>
            </div>
            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Start date</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{formatDate(selectedProject.startDate)}</dd>
            </div>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Estimated completion</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {formatDate(selectedProject.estimatedEndDate)}
                <span className="ml-2 text-sm text-gray-500">
                  ({calculateDaysRemaining(selectedProject.estimatedEndDate)} days remaining)
                </span>
              </dd>
            </div>
            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Budget</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">${selectedProject.budget.toLocaleString()}</dd>
            </div>
          </dl>
        </div>
      </div>
      
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Progress</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Current project completion status.</p>
        </div>
        <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-700">{selectedProject.progress}% Complete</span>
            <span className="text-sm text-gray-500">{selectedProject.tasks.filter(t => t.status === 'completed').length} of {selectedProject.tasks.length} tasks completed</span>
          </div>
          <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${selectedProject.progress}%` }}></div>
          </div>
        </div>
      </div>
      
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Recent Updates</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Latest project activity.</p>
        </div>
        <div className="border-t border-gray-200">
          <ul className="divide-y divide-gray-200">
            {selectedProject.updates.slice(-3).reverse().map((update) => (
              <li key={update.id} className="px-4 py-4">
                <div className="flex space-x-3">
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-medium">{update.author}</h3>
                      <p className="text-sm text-gray-500">{formatDate(update.date)}</p>
                    </div>
                    <p className="text-sm text-gray-500">{update.message}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
  
  const renderTasksTab = () => (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Project Tasks</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">Track the progress of individual tasks.</p>
      </div>
      <div className="border-t border-gray-200">
        <ul className="divide-y divide-gray-200">
          {selectedProject.tasks.map((task) => (
            <li key={task.id} className="px-4 py-4 sm:px-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    id={`task-${task.id}`}
                    name={`task-${task.id}`}
                    type="checkbox"
                    checked={task.status === 'completed'}
                    onChange={(e) => handleTaskStatusChange(task.id, e.target.checked ? 'completed' : 'pending')}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor={`task-${task.id}`} className={`ml-3 block text-sm font-medium ${task.status === 'completed' ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
                    {task.name}
                  </label>
                </div>
                <div className="flex items-center">
                  <span className="text-sm text-gray-500 mr-4">{formatDate(task.date)}</span>
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(task.status)}`}>
                    {getStatusText(task.status)}
                  </span>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
  
  const renderUpdatesTab = () => (
    <div className="space-y-6">
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Project Updates</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Communication history for this project.</p>
        </div>
        <div className="border-t border-gray-200">
          <ul className="divide-y divide-gray-200">
            {selectedProject.updates.map((update) => (
              <li key={update.id} className="px-4 py-4">
                <div className="flex space-x-3">
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-medium">{update.author}</h3>
                      <p className="text-sm text-gray-500">{formatDate(update.date)}</p>
                    </div>
                    <p className="text-sm text-gray-500">{update.message}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Add Update</h3>
          <div className="mt-2 max-w-xl text-sm text-gray-500">
            <p>Add a new update or note about this project.</p>
          </div>
          <div className="mt-5">
            <textarea
              rows="3"
              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border border-gray-300 rounded-md"
              placeholder="Enter your update here..."
              value={newUpdate}
              onChange={(e) => setNewUpdate(e.target.value)}
            ></textarea>
          </div>
          <div className="mt-5">
            <button
              type="button"
              onClick={addUpdate}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Post Update
            </button>
          </div>
        </div>
      </div>
    </div>
  );
  
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="py-10">
        <header>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold leading-tight text-gray-900">Project Tracker</h1>
          </div>
        </header>
        <main>
          <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div className="px-4 py-8 sm:px-0">
              {/* Project Selection */}
              <div className="mb-6">
                <label htmlFor="project-select" className="block text-sm font-medium text-gray-700">
                  Select Project
                </label>
                <select
                  id="project-select"
                  name="project-select"
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  value={selectedProject.id}
                  onChange={(e) => setSelectedProject(projects.find(p => p.id === parseInt(e.target.value)))}
                >
                  {projects.map((project) => (
                    <option key={project.id} value={project.id}>
                      {project.name}
                    </option>
                  ))}
                </select>
              </div>
              
              {/* Tabs */}
              <div className="border-b border-gray-200">
                <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`${
                      activeTab === 'overview'
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                  >
                    Overview
                  </button>
                  <button
                    onClick={() => setActiveTab('tasks')}
                    className={`${
                      activeTab === 'tasks'
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                  >
                    Tasks
                  </button>
                  <button
                    onClick={() => setActiveTab('updates')}
                    className={`${
                      activeTab === 'updates'
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                  >
                    Updates
                  </button>
                </nav>
              </div>
              
              {/* Tab Content */}
              <div className="mt-6">
                {activeTab === 'overview' && renderOverviewTab()}
                {activeTab === 'tasks' && renderTasksTab()}
                {activeTab === 'updates' && renderUpdatesTab()}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ProjectTracker;
